
import random
from datetime import datetime, time, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from Production_inventory.models import Product, SupplierReceipt
from Production_inventory.services import record_supplier_receipt

from Distribution.models import (
    Distribution,
    DistributionDestination,
    DistributionItem,
)
from Distribution.services import dispatch_distribution

from Sales.models import Sale, SaleItem


DEMO_PREFIX = "KQUENCH_DEMO"

DAYS = 60

PRODUCTS = [
    {
        "name": "Bottled Water 500ml",
        "size": 500,
        "price": Decimal("50.00"),
    },
    {
        "name": "Bottled Water 1L",
        "size": 1000,
        "price": Decimal("80.00"),
    },
]

DESTINATIONS = [
    {
        "name": "Demo Aircraft Operations",
        "type": "AIRCRAFT",
    },
    {
        "name": "Demo Airline Cafe",
        "type": "CAFE",
    },
    {
        "name": "Demo Airline Lounge",
        "type": "LOUNGE",
    },
]

# Quantities are bottles, not litres.
DEMAND_RANGES = {
    "AIRCRAFT": {
        500: (420, 650),
        1000: (100, 180),
    },
    "CAFE": {
        500: (70, 130),
        1000: (35, 70),
    },
    "LOUNGE": {
        500: (90, 160),
        1000: (50, 90),
    },
    "EXTERNAL": {
        500: (100, 250),
        1000: (40, 100),
    },
}


class Command(BaseCommand):

    help = "Populate KQuench with 60 days of demonstration data."

    @transaction.atomic
    def handle(self, *args, **options):

        # Prevent accidental duplication.
        if (
            Distribution.objects.filter(
                notes__startswith=DEMO_PREFIX
            ).exists()
            or SupplierReceipt.objects.filter(
                notes__startswith=DEMO_PREFIX
            ).exists()
            or Sale.objects.filter(
                delivery_address__startswith=DEMO_PREFIX
            ).exists()
        ):
            raise CommandError(
                "Demo records already exist. "
                "The command has stopped to prevent duplicates."
            )

        rng = random.Random(20261125)

        self.stdout.write("Creating products...")

        products = {}

        for item in PRODUCTS:

            product, created = Product.objects.get_or_create(
                product_name=item["name"],
                defaults={
                    "unit_size_ml": item["size"],
                    "unit_price": item["price"],
                    "description": "KQuench demonstration bottled water",
                    "is_active": True,
                },
            )

            if (
                product.unit_size_ml != item["size"]
                or product.unit_price != item["price"]
            ):
                raise CommandError(
                    f"Existing product {product.product_name} "
                    "has different specifications."
                )

            products[item["size"]] = product

        self.stdout.write("Creating supplier receipts...")

        today = timezone.localdate()
        first_day = today - timedelta(days=DAYS - 1)

        # Receipts are recorded through the actual inventory service.
        receipt_plan = [
            (500, 40000, 0),
            (500, 35000, 30),
            (1000, 15000, 0),
            (1000, 15000, 30),
        ]

        for index, (size, quantity, day_offset) in enumerate(
            receipt_plan,
            start=1,
        ):

            receipt_date = first_day + timedelta(
                days=day_offset
            )

            record_supplier_receipt({
                "supplier_name": "KQuench Demo Water Supplier",
                "delivery_reference": (
                    f"KQ-DEMO-RECEIPT-{index:03d}"
                ),
                "product": products[size],
                "received_date": receipt_date,
                "quantity_received": quantity,
                "notes": (
                    f"{DEMO_PREFIX} - Demonstration stock receipt"
                ),
                "received_by": None,
            })

        self.stdout.write("Creating internal destinations...")

        destinations = {}

        for destination_data in DESTINATIONS:

            destination, _ = (
                DistributionDestination.objects.get_or_create(
                    destination_name=destination_data["name"],
                    defaults={
                        "destination_type": destination_data["type"],
                        "description": (
                            f"{DEMO_PREFIX} - "
                            "Demonstration destination"
                        ),
                        "is_active": True,
                    },
                )
            )

            if destination.destination_type != destination_data["type"]:
                raise CommandError(
                    f"Destination {destination.destination_name} "
                    "has an unexpected destination type."
                )

            destinations[destination_data["type"]] = destination

        self.stdout.write(
            f"Creating and dispatching {DAYS} days of deliveries..."
        )

        internal_count = 0
        external_count = 0

        for day_number in range(DAYS):

            delivery_day = first_day + timedelta(
                days=day_number
            )

            # Historical dispatch timestamps.
            historical_dispatch = timezone.make_aware(
                datetime.combine(
                    delivery_day,
                    time(10, 0),
                )
            )

            # Create one internal distribution per supported channel.
            for destination_type in [
                "AIRCRAFT",
                "CAFE",
                "LOUNGE",
            ]:

                distribution = Distribution.objects.create(
                    distribution_type="INTERNAL",
                    destination=destinations[destination_type],
                    sale=None,
                    distribution_date=historical_dispatch
                    - timedelta(hours=1),
                    vehicle_number="KQ-DEMO-001",
                    driver_name="Demo Distribution Driver",
                    status="PENDING",
                    notes=(
                        f"{DEMO_PREFIX} - "
                        f"{destination_type} - {delivery_day}"
                    ),
                    created_by=None,
                )

                for size in [500, 1000]:

                    minimum, maximum = DEMAND_RANGES[
                        destination_type
                    ][size]

                    quantity = rng.randint(minimum, maximum)

                    DistributionItem.objects.create(
                        distribution=distribution,
                        product=products[size],
                        sale_item=None,
                        quantity_dispatched=quantity,
                    )

                # Use the actual stock deduction service.
                dispatch_distribution(
                    distribution.distribution_id,
                    None,
                )

                # Backdate the dispatch after successful stock deduction.
                Distribution.objects.filter(
                    pk=distribution.pk
                ).update(
                    dispatch_date=historical_dispatch
                )

                internal_count += 1

            # Create one external customer sale per day.
            customer_number = day_number + 1

            sale = Sale.objects.create(
                customer_name=(
                    f"Demo External Customer {customer_number:03d}"
                ),
                customer_phone="0700000000",
                delivery_address=(
                    f"{DEMO_PREFIX} - "
                    f"External Customer {customer_number:03d}"
                ),
                payment_status="PAID",
                sale_status="PENDING",
                created_by=None,
            )

            sale_total = Decimal("0.00")
            sale_items = []

            for size in [500, 1000]:

                minimum, maximum = DEMAND_RANGES[
                    "EXTERNAL"
                ][size]

                quantity = rng.randint(minimum, maximum)

                product = products[size]

                sale_item = SaleItem.objects.create(
                    sale=sale,
                    product=product,
                    quantity=quantity,
                    unit_price=product.unit_price,
                )

                sale_items.append(sale_item)
                sale_total += sale_item.subtotal

            sale.total_amount = sale_total
            sale.save(update_fields=["total_amount"])

            external_distribution = Distribution.objects.create(
                distribution_type="EXTERNAL",
                destination=None,
                sale=sale,
                distribution_date=historical_dispatch
                - timedelta(hours=1),
                vehicle_number="KQ-DEMO-002",
                driver_name="Demo External Delivery Driver",
                status="PENDING",
                notes=(
                    f"{DEMO_PREFIX} - "
                    f"External delivery - {delivery_day}"
                ),
                created_by=None,
            )

            for sale_item in sale_items:

                DistributionItem.objects.create(
                    distribution=external_distribution,
                    product=sale_item.product,
                    sale_item=sale_item,
                    quantity_dispatched=sale_item.quantity,
                )

            dispatch_distribution(
                external_distribution.distribution_id,
                None,
            )

            Distribution.objects.filter(
                pk=external_distribution.pk
            ).update(
                dispatch_date=historical_dispatch
            )

            external_count += 1

            if (day_number + 1) % 10 == 0:
                self.stdout.write(
                    f"Completed {day_number + 1}/{DAYS} days..."
                )

        self.stdout.write("")
        self.stdout.write(
            self.style.SUCCESS(
                "KQuench demonstration data created successfully."
            )
        )

        self.stdout.write(f"Historical days: {DAYS}")
        self.stdout.write(f"Internal distributions: {internal_count}")
        self.stdout.write(f"External distributions: {external_count}")
        self.stdout.write(
            f"Total distributions: {internal_count + external_count}"
        )
