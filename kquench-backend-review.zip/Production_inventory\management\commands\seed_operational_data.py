
import math
import random
from collections import defaultdict
from datetime import datetime, time, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from Production_inventory.models import (
    Product, Inventory, InventoryTransaction, SupplierReceipt
)
from Production_inventory.services import record_supplier_receipt

from Distribution.models import (
    Distribution, DistributionDestination, DistributionItem
)
from Distribution.services import dispatch_distribution

from Sales.models import Sale, SaleItem


DAYS = 60
SEED_MARKER = "KQ_OPERATIONAL_SEED|"
OLD_MARKER = "KQUENCH_DEMO"

PRODUCTS = [
    ("Bottled Water 300ml", 300, Decimal("30.00")),
    ("Bottled Water 500ml", 500, Decimal("50.00")),
    ("Bottled Water 1L", 1000, Decimal("80.00")),
]

DESTINATIONS = {
    "AIRCRAFT": ("Aircraft Operations", "Aircraft water supply"),
    "CAFE": ("Airline Cafe", "Cafe water supply"),
    "LOUNGE": ("Airline Lounge", "Lounge water supply"),
}

DEMAND_RANGES = {
    "AIRCRAFT": (250, 450),
    "CAFE": (50, 100),
    "LOUNGE": (70, 130),
    "EXTERNAL": (80, 160),
}

# Different dispatch windows for each destination.
TIME_WINDOWS = {
    "AIRCRAFT": (time(5, 30), time(8, 30)),
    "CAFE": (time(9, 0), time(11, 30)),
    "LOUNGE": (time(12, 30), time(15, 30)),
    "EXTERNAL": (time(15, 30), time(18, 30)),
}


class Command(BaseCommand):
    help = "Reseed chronological KQuench operational history"

    @transaction.atomic
    def handle(self, *args, **options):
        self.stdout.write("Preparing chronological operational history...")

        rng = random.Random(42)

        self.clean_previous_seed()

        products = self.prepare_products()
        destinations = self.prepare_destinations()

        end_date = timezone.localdate()
        start_date = end_date - timedelta(days=DAYS - 1)

        plans = self.build_daily_plans(rng, start_date)

        # Receive stock at the beginning of each week,
        # then dispatch that week's demand.
        for week_start in range(0, DAYS, 7):
            week_plans = plans[week_start:week_start + 7]

            self.receive_weekly_stock(
                week_plans, products, rng
            )

            for plan in week_plans:
                self.process_day(
                    plan, products, destinations, rng
                )

        self.print_summary(products)

        self.stdout.write(self.style.SUCCESS(
            "\nChronological operational data created successfully."
        ))

    def clean_previous_seed(self):
        old_distributions = Distribution.objects.filter(
            Q(notes__startswith=OLD_MARKER)
            | Q(notes__startswith=SEED_MARKER)
        )

        old_items = DistributionItem.objects.filter(
            distribution__in=old_distributions
        )

        old_receipts = SupplierReceipt.objects.filter(
            Q(notes__startswith=OLD_MARKER)
            | Q(notes__startswith=SEED_MARKER)
        )

        old_transactions = InventoryTransaction.objects.filter(
            Q(distribution_item__in=old_items)
            | Q(supplier_receipt__in=old_receipts)
        )

        # Reverse only the stock movements from generated records.
        stock_changes = defaultdict(int)

        for tx in old_transactions.select_related("product"):
            if tx.transaction_type == "SUPPLIER_RECEIPT":
                stock_changes[tx.product_id] -= tx.quantity

            elif tx.transaction_type in (
                "INTERNAL_DISTRIBUTION",
                "EXTERNAL_SALE",
            ):
                stock_changes[tx.product_id] += tx.quantity

        for product_id, change in stock_changes.items():
            inventory = Inventory.objects.filter(
                product_id=product_id
            ).first()

            if inventory:
                new_quantity = inventory.quantity_available + change

                if new_quantity < 0:
                    raise CommandError(
                        f"Cannot safely reverse stock for product {product_id}."
                    )

                inventory.quantity_available = new_quantity
                inventory.save(update_fields=[
                    "quantity_available", "last_updated"
                ])

        old_sale_ids = list(
            old_distributions.exclude(sale__isnull=True)
            .values_list("sale_id", flat=True)
        )

        old_sales = Sale.objects.filter(
            Q(sale_id__in=old_sale_ids)
            | Q(delivery_address__startswith=OLD_MARKER)
            | Q(delivery_address__startswith=SEED_MARKER)
        )

        old_transactions.delete()
        old_distributions.delete()
        old_sales.delete()
        old_receipts.delete()

        self.stdout.write(
            "Previous generated history removed and stock movements reversed."
        )

    def prepare_products(self):
        products = {}

        for name, size, price in PRODUCTS:
            product, _ = Product.objects.get_or_create(
                product_name=name,
                defaults={
                    "unit_size_ml": size,
                    "unit_price": price,
                    "is_active": True,
                },
            )

            if product.unit_size_ml != size:
                raise CommandError(
                    f"Incorrect bottle size for {product.product_name}."
                )

            # Preserve existing product prices.
            product.is_active = True
            product.save(update_fields=["is_active"])

            Inventory.objects.get_or_create(
                product=product,
                defaults={
                    "quantity_available": 0,
                    "reorder_level": 0,
                },
            )

            products[size] = product

        # Keep this historical product inactive because it has
        # an existing sale, production batch and inventory transaction.
        legacy = Product.objects.filter(
            product_name="KQuench 1L"
        ).first()

        if legacy:
            legacy.is_active = False
            legacy.save(update_fields=["is_active"])

        # The old 300ml product was confirmed to have no references.
        legacy_300 = Product.objects.filter(
            product_name="KQuench 300ml"
        ).first()

        if legacy_300:
            if (
                InventoryTransaction.objects.filter(product=legacy_300).exists()
                or SupplierReceipt.objects.filter(product=legacy_300).exists()
                or DistributionItem.objects.filter(product=legacy_300).exists()
                or SaleItem.objects.filter(product=legacy_300).exists()
            ):
                raise CommandError(
                    "Legacy KQuench 300ml has references and cannot be deleted."
                )

            Inventory.objects.filter(product=legacy_300).delete()
            legacy_300.delete()

        return products

    def prepare_destinations(self):
        result = {}

        for destination_type, (name, description) in DESTINATIONS.items():
            old = DistributionDestination.objects.filter(
                destination_type=destination_type,
                destination_name__startswith="Demo ",
            ).first()

            destination = DistributionDestination.objects.filter(
                destination_name=name
            ).first()

            if old and not destination:
                old.destination_name = name
                old.description = description
                old.is_active = True
                old.save()
                destination = old

            if not destination:
                destination = DistributionDestination.objects.create(
                    destination_name=name,
                    destination_type=destination_type,
                    description=description,
                    is_active=True,
                )

            result[destination_type] = destination

        return result

    def bottle_quantities(self, litres, rng):
        # Split demand across bottle sizes:
        # 30% in 300ml, 40% in 500ml and 30% in 1L.
        return {
            300: round(litres * 0.30 / 0.30),
            500: round(litres * 0.40 / 0.50),
            1000: round(litres * 0.30 / 1.00),
        }

    def build_daily_plans(self, rng, start_date):
        plans = []

        for day_number in range(DAYS):
            current_date = start_date + timedelta(days=day_number)

            categories = {}

            for category, (minimum, maximum) in DEMAND_RANGES.items():
                litres = rng.randint(minimum, maximum)
                categories[category] = self.bottle_quantities(
                    litres, rng
                )

            plans.append({
                "date": current_date,
                "categories": categories,
            })

        return plans

    def historical_datetime(self, current_date, category, rng):
        start, end = TIME_WINDOWS[category]

        start_minutes = start.hour * 60 + start.minute
        end_minutes = end.hour * 60 + end.minute

        minute = rng.randint(start_minutes, end_minutes)

        selected_time = time(
            minute // 60,
            minute % 60,
            rng.randint(0, 59),
        )

        naive_datetime = datetime.combine(
            current_date, selected_time
        )

        return timezone.make_aware(
            naive_datetime,
            timezone.get_current_timezone(),
        )

    def receive_weekly_stock(self, week_plans, products, rng):
        weekly_totals = defaultdict(int)

        for plan in week_plans:
            for quantities in plan["categories"].values():
                for size, quantity in quantities.items():
                    weekly_totals[size] += quantity

        receipt_date = week_plans[0]["date"]
        

        for size, product in products.items():
            quantity = math.ceil(weekly_totals[size] * 1.10)

            reference = (
                f"KQ-OPS-{receipt_date:%Y%m%d}-{size}"
            )

            receipt_time = timezone.make_aware(
                datetime.combine(receipt_date, time(4, 30)),
                timezone.get_current_timezone(),
            )

            record_supplier_receipt({
                "supplier_name": "KQuench Water Supplier",
                "delivery_reference": reference,
                "product": product,
                "received_date": receipt_date,
                "quantity_received": quantity,
                "notes": (
                    f"{SEED_MARKER}Weekly supplier receipt"
                ),
                "received_by": None,
            })

            receipt = SupplierReceipt.objects.get(
                delivery_reference=reference
            )

            # Backdate the linked inventory transaction so that
            # the stock ledger reflects the historical receipt date.
            InventoryTransaction.objects.filter(
                supplier_receipt=receipt
            ).update(transaction_date=receipt_time)

            self.stdout.write(
                f"Received {quantity:,} units of {product.product_name} "
                f"on {receipt_date}."
            )

    def create_items(self, distribution, quantities, products):
        for size, quantity in quantities.items():
            DistributionItem.objects.create(
                distribution=distribution,
                product=products[size],
                quantity_dispatched=quantity,
            )

    def dispatch_and_backdate(self, distribution, dispatch_time):
        dispatch_distribution(
            distribution.distribution_id, None
        )

        distribution.dispatch_date = dispatch_time
        distribution.save(update_fields=["dispatch_date"])

        # The dispatch service creates one stock transaction per item.
        for item in distribution.items.all():
            InventoryTransaction.objects.filter(
                distribution_item=item
            ).update(transaction_date=dispatch_time)

    def process_day(self, plan, products, destinations, rng):
        current_date = plan["date"]
        categories = plan["categories"]

        for category in ("AIRCRAFT", "CAFE", "LOUNGE"):
            dispatch_time = self.historical_datetime(
                current_date, category, rng
            )

            distribution = Distribution.objects.create(
                distribution_type="INTERNAL",
                destination=destinations[category],
                distribution_date=dispatch_time,
                status="PENDING",
                notes=(
                    f"{SEED_MARKER}{category}|{current_date}"
                ),
                created_by=None,
            )

            self.create_items(
                distribution, categories[category], products
            )

            self.dispatch_and_backdate(
                distribution, dispatch_time
            )

        # One modest external customer order per day.
        dispatch_time = self.historical_datetime(
            current_date, "EXTERNAL", rng
        )

        sale = Sale.objects.create(
            customer_name=(
                f"External Customer {current_date:%Y%m%d}"
            ),
            customer_phone="0700000000",
            delivery_address="Nairobi, Kenya",
            total_amount=Decimal("0.00"),
            payment_status="PAID",
            sale_status="PENDING",
            created_by=None,
        )

        total_amount = Decimal("0.00")
        sale_items = {}

        for size, quantity in categories["EXTERNAL"].items():
            product = products[size]

            item = SaleItem.objects.create(
                sale=sale,
                product=product,
                quantity=quantity,
                unit_price=product.unit_price,
            )

            sale_items[size] = item
            total_amount += item.subtotal

        sale.total_amount = total_amount
        sale.save(update_fields=["total_amount"])

        # Set the historical sale date.
        Sale.objects.filter(pk=sale.pk).update(
            sale_date=dispatch_time
        )

        distribution = Distribution.objects.create(
            distribution_type="EXTERNAL",
            sale=sale,
            distribution_date=dispatch_time,
            status="PENDING",
            notes=(
                f"{SEED_MARKER}EXTERNAL|{current_date}"
            ),
            created_by=None,
        )

        for size, quantity in categories["EXTERNAL"].items():
            DistributionItem.objects.create(
                distribution=distribution,
                product=products[size],
                sale_item=sale_items[size],
                quantity_dispatched=quantity,
            )

        self.dispatch_and_backdate(
            distribution, dispatch_time
        )

    def print_summary(self, products):
        self.stdout.write("\nFINAL INVENTORY:")

        for size, product in products.items():
            inventory = Inventory.objects.get(product=product)

            self.stdout.write(
                f"{product.product_name}: "
                f"{inventory.quantity_available:,} units remaining"
            )

        self.stdout.write("\nHISTORY:")
        self.stdout.write(f"Historical days: {DAYS}")
        self.stdout.write(f"Weekly receipts: {math.ceil(DAYS / 7)} per product")
        self.stdout.write(f"Internal distributions: {DAYS * 3}")
        self.stdout.write(f"External distributions: {DAYS}")
        self.stdout.write(f"External sales: {DAYS}")
